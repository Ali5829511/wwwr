# دليل الاستخدام السريع - نظام التعرف على اللوحات
# Quick Usage Guide - Plate Recognition System

## 📋 نظرة سريعة / Quick Overview

```
┌─────────────────────────────────────────────────────────────┐
│              🚗 نظام التعرف على لوحات السيارات              │
│          Automatic License Plate Recognition System         │
└─────────────────────────────────────────────────────────────┘

    📁 images/                    🐍 Python Script
    ├── car1.jpg      ────────►   auto_plate_recognition.py
    ├── car2.jpg                           │
    └── car3.jpg                           │
                                           ▼
                              🌐 Plate Recognizer API
                                           │
                                           ▼
                              💾 SQLite Database (traffic.db)
                              ├── 🚗 cars table
                              └── 📋 violations table
                                           │
                                           ▼
                              📁 processed_images/
                              ├── car1.jpg (مع بيانات)
                              ├── car2.jpg (مع بيانات)
                              └── car3.jpg (مع بيانات)
```

---

## ⚡ البدء السريع في 5 خطوات / Quick Start in 5 Steps

### الخطوة 1: التثبيت / Step 1: Installation
```bash
pip3 install -r requirements.txt
```

### الخطوة 2: الإعدادات / Step 2: Configuration
```bash
cp plate_recognition_config.json.example plate_recognition_config.json
nano plate_recognition_config.json  # أضف API Token
```

### الخطوة 3: تحضير الصور / Step 3: Prepare Images
```bash
# ضع صور السيارات في مجلد images/
mkdir -p images
# انسخ صورك إلى images/
```

### الخطوة 4: التشغيل / Step 4: Run
```bash
python3 auto_plate_recognition.py
# أو / or
./start_plate_recognition.sh
```

### الخطوة 5: النتائج / Step 5: Results
```bash
# راجع الصور المعالجة / Check processed images
ls processed_images/

# راجع قاعدة البيانات / Check database
sqlite3 traffic.db "SELECT * FROM violations;"
```

---

## 🎯 مثال تشغيل / Example Run

```bash
$ python3 auto_plate_recognition.py

============================================================
🚗 نظام التعرف التلقائي على لوحات السيارات
🚗 Automatic License Plate Recognition System
============================================================

✅ قاعدة البيانات جاهزة
✅ Database ready
✅ المجلدات جاهزة: images, processed_images

============================================================
🚀 بدء معالجة الصور / Starting image processing
============================================================

📊 عدد الصور المكتشفة / Images found: 3

[1/3] معالجة / Processing: car1.jpg

📸 الصورة / Image: car1.jpg
🔍 اللوحة / Plate: ABC123
🚗 النوع / Type: Toyota Camry
🎨 اللون / Color: White
⏰ الوقت / Time: 2025-11-11T06:45:00
✅ تم تسجيل مخالفة تلقائية
✅ Violation recorded automatically
📁 تم حفظ الصورة / Image saved: processed_images/car1.jpg
------------------------------------------------------------

[2/3] معالجة / Processing: car2.jpg
...

============================================================
📊 ملخص المعالجة / Processing Summary
============================================================
✅ تمت معالجتها بنجاح / Successfully processed: 3
❌ فشلت / Failed: 0
📁 الصور المحفوظة في / Images saved in: /path/to/processed_images
============================================================
```

---

## 📊 بنية قاعدة البيانات / Database Structure

### جدول السيارات / Cars Table
```
┌────────────┬──────────────┬────────────┬────────┬──────┬────────┐
│ car_id     │ plate_number │ owner_name │ model  │ year │ color  │
├────────────┼──────────────┼────────────┼────────┼──────┼────────┤
│ 1          │ ABC123       │ أحمد       │ Camry  │ 2023 │ أبيض   │
│ 2          │ XYZ789       │ محمد       │ Accord │ 2022 │ أسود   │
└────────────┴──────────────┴────────────┴────────┴──────┴────────┘
```

### جدول المخالفات / Violations Table
```
┌──────────────┬────────┬──────────────────────────┬──────────────────┬─────────────┬──────────────┐
│ violation_id │ car_id │ violation_type           │ violation_date   │ fine_amount │ officer_name │
├──────────────┼────────┼──────────────────────────┼──────────────────┼─────────────┼──────────────┤
│ 1            │ 1      │ دخول موقف خاص بدون تصريح │ 2025-11-11 06:45 │ 1000        │ نظام تلقائي  │
│ 2            │ 2      │ دخول موقف خاص بدون تصريح │ 2025-11-11 07:30 │ 1000        │ نظام تلقائي  │
└──────────────┴────────┴──────────────────────────┴──────────────────┴─────────────┴──────────────┘
```

---

## 🔧 الإعدادات الشائعة / Common Settings

### إعدادات افتراضية / Default Settings
```json
{
    "input_folder": "images",
    "output_folder": "processed_images",
    "violation_type": "دخول موقف خاص بدون تصريح",
    "fine_amount": 1000
}
```

### إعدادات مخصصة / Custom Settings
```json
{
    "input_folder": "D:/صور_اليوم",
    "output_folder": "D:/معالجة_اليوم",
    "violation_type": "وقوف في منطقة محظورة",
    "fine_amount": 500
}
```

---

## 🐛 حل المشاكل / Troubleshooting

### مشكلة: لا توجد صور
```bash
⚠️ No images found in input folder
```
**الحل / Solution:**
- تأكد من وجود صور في مجلد `images/`
- الصيغ المدعومة: .jpg, .jpeg, .png, .bmp

### مشكلة: خطأ API
```bash
❌ Error: API token not set
```
**الحل / Solution:**
- افتح `plate_recognition_config.json`
- أضف API Token من https://platerecognizer.com/

### مشكلة: خطأ اتصال
```bash
⚠️ API connection error
```
**الحل / Solution:**
- تحقق من اتصال الإنترنت
- تحقق من صحة API Token

---

## 📈 إحصائيات الأداء / Performance Stats

| المعيار / Metric | القيمة / Value |
|------------------|----------------|
| **سرعة المعالجة** | 2-5 ثانية/صورة |
| **دقة التعرف** | 95%+ (حسب جودة الصورة) |
| **الصيغ المدعومة** | JPG, JPEG, PNG, BMP |
| **حجم قاعدة البيانات** | ~500KB لكل 1000 مخالفة |

---

## 🎓 أمثلة متقدمة / Advanced Examples

### استعلام عن مخالفات سيارة معينة
```bash
sqlite3 traffic.db "
SELECT 
    c.plate_number,
    c.owner_name,
    v.violation_type,
    v.violation_date,
    v.fine_amount
FROM violations v
JOIN cars c ON v.car_id = c.car_id
WHERE c.plate_number = 'ABC123';
"
```

### عرض إجمالي الغرامات
```bash
sqlite3 traffic.db "
SELECT 
    SUM(fine_amount) as total_fines,
    COUNT(*) as total_violations
FROM violations;
"
```

### أحدث 10 مخالفات
```bash
sqlite3 traffic.db "
SELECT 
    c.plate_number,
    v.violation_type,
    v.violation_date
FROM violations v
JOIN cars c ON v.car_id = c.car_id
ORDER BY v.violation_date DESC
LIMIT 10;
"
```

---

## 🔗 روابط مفيدة / Useful Links

- 📖 [دليل كامل / Full Guide](docs/AUTO_PLATE_RECOGNITION.md)
- 🌐 [Plate Recognizer API](https://platerecognizer.com/)
- 🐍 [Python Documentation](https://docs.python.org/3/)
- 💾 [SQLite Documentation](https://www.sqlite.org/docs.html)

---

## ✨ نصائح للأداء الأفضل / Tips for Best Performance

1. **جودة الصور**: استخدم صور واضحة بدقة عالية
2. **إضاءة جيدة**: تأكد من إضاءة اللوحة جيداً
3. **زاوية مناسبة**: صور من الأمام أو الخلف مباشرة
4. **حفظ النسخ الاحتياطية**: احتفظ بنسخة من `traffic.db`
5. **مراقبة الحصة**: راقب استهلاك API لتجنب تجاوز الحد

---

## 📞 الدعم الفني / Support

للحصول على المساعدة:
- افتح Issue على GitHub
- راجع الوثائق الكاملة في `docs/AUTO_PLATE_RECOGNITION.md`
- اقرأ قسم استكشاف الأخطاء

---

**✨ بالتوفيق في استخدام النظام! / Good luck with the system! ✨**
