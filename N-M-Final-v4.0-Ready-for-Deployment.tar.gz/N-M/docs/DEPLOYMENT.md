# دليل النشر والتشغيل - Deployment Guide
# نظام إدارة إسكان أعضاء هيئة التدريس

## 📋 نظرة عامة

هذا الدليل يوضح خطوات نشر النظام في بيئة الإنتاج Production Environment.

## ⚠️ متطلبات ما قبل النشر

### 1. البنية التحتية المطلوبة

#### الحد الأدنى:
- **خادم ويب**: Apache 2.4+ أو Nginx 1.18+
- **نظام التشغيل**: Linux (Ubuntu 20.04+ مفضل) أو Windows Server
- **شهادة SSL**: لتفعيل HTTPS (مطلوب للإنتاج)
- **اسم نطاق**: domain name للوصول للنظام

#### الموصى به للإنتاج:
- **قاعدة بيانات خلفية**: PostgreSQL 13+ أو MySQL 8+
- **خادم تطبيقات**: Node.js 16+ أو Python 3.9+
- **نظام تخزين**: لحفظ الصور والمرفقات
- **نظام نسخ احتياطي**: Backup system

### 2. المتطلبات الأمنية المهمة

⚠️ **تحذير**: النظام الحالي يستخدم localStorage وهو مناسب للتطوير فقط!

قبل النشر في الإنتاج، يجب تطبيق:

1. **تشفير كلمات المرور**
   - استخدام bcrypt أو argon2
   - عدم تخزين كلمات المرور بنص عادي

2. **قاعدة بيانات آمنة**
   - استبدال localStorage بقاعدة بيانات حقيقية
   - PostgreSQL أو MySQL أو MongoDB

3. **API خلفي آمن**
   - بناء REST API مع Express.js أو Django
   - تطبيق معايير الأمان (OWASP)

4. **HTTPS إلزامي**
   - الحصول على شهادة SSL
   - إجبار جميع الاتصالات على HTTPS

5. **توكنات JWT**
   - استبدال localStorage بـ JWT tokens
   - تحديد مدة صلاحية للتوكنات

6. **حماية إضافية**
   - Rate limiting لمنع Brute force
   - CSRF protection
   - XSS protection
   - Input validation
   - SQL injection protection

## 🚀 خطوات النشر

### الخيار 0: GitHub Pages (موصى به للتطوير والتجربة)

✅ **النظام منشور حالياً على GitHub Pages!**

يمكن الوصول للنظام عبر: [https://ali5829511.github.io/N-M/](https://ali5829511.github.io/N-M/)

#### المميزات:
- ✅ نشر تلقائي عند كل تحديث على branch main
- ✅ مجاني بالكامل
- ✅ شهادة SSL مجانية (HTTPS)
- ✅ لا يحتاج إعداد خادم

#### كيفية التحديث:
1. قم بعمل commit للتغييرات على branch main
2. سيتم النشر تلقائياً عبر GitHub Actions
3. انتظر 1-2 دقيقة حتى يكتمل النشر
4. تحقق من الموقع المنشور

#### الملفات المهمة:
- `.github/workflows/deploy.yml` - ملف GitHub Actions للنشر التلقائي
- جميع ملفات HTML/CSS/JS في المجلد الرئيسي

⚠️ **تنبيه**: GitHub Pages مناسب للتطوير والاختبار فقط. للإنتاج الحقيقي، راجع الخيارات التالية.

### الخيار 1: نشر على خادم خاص (للتطوير والاختبار المتقدم)

#### باستخدام Apache:

1. **تثبيت Apache**
```bash
sudo apt update
sudo apt install apache2
```

2. **نسخ الملفات**
```bash
sudo cp -r /path/to/N-M/* /var/www/html/traffic-system/
```

3. **ضبط الصلاحيات**
```bash
sudo chown -R www-data:www-data /var/www/html/traffic-system/
sudo chmod -R 755 /var/www/html/traffic-system/
```

4. **إعادة تشغيل Apache**
```bash
sudo systemctl restart apache2
```

#### باستخدام Nginx:

1. **تثبيت Nginx**
```bash
sudo apt update
sudo apt install nginx
```

2. **إنشاء ملف الإعدادات**
```bash
sudo nano /etc/nginx/sites-available/traffic-system
```

3. **إضافة الإعدادات**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/html/traffic-system;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    # تفعيل الضغط
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
```

4. **تفعيل الموقع**
```bash
sudo ln -s /etc/nginx/sites-available/traffic-system /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### الخيار 2: نشر آمن (موصى به للإنتاج)

هذا يتطلب تطوير إضافي للنظام:

#### 1. بناء Backend API

```bash
# مثال باستخدام Node.js و Express
mkdir backend
cd backend
npm init -y
npm install express bcrypt jsonwebtoken pg dotenv cors helmet express-rate-limit
```

#### 2. قاعدة البيانات

```sql
-- مثال لإنشاء جداول PostgreSQL
CREATE DATABASE traffic_system;

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'active',
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

CREATE TABLE violations (
    id SERIAL PRIMARY KEY,
    plate_number VARCHAR(20),
    violation_date DATE,
    violation_type VARCHAR(100),
    location VARCHAR(200),
    amount DECIMAL(10,2),
    status VARCHAR(20),
    created_by INTEGER REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP
);
```

#### 3. تطبيق HTTPS

```bash
# باستخدام Let's Encrypt
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 📝 إعدادات بعد النشر

### 1. تغيير بيانات المستخدمين الافتراضية

⚠️ **مهم جداً**: قم بتغيير كلمات المرور الافتراضية فوراً!

الوصول إلى النظام وتحديث:
- كلمة مرور مدير النظام
- كلمات مرور جميع المستخدمين
- بيانات الاتصال (الإيميلات)

### 2. ضبط إعدادات الأمان

في ملف `js/auth.js`:
```javascript
// تحديث مدة انتهاء الجلسة
this.sessionTimeout = 30 * 60 * 1000; // 30 دقيقة
```

### 3. إعداد النسخ الاحتياطي

```bash
# نسخ احتياطي يومي لـ localStorage (مؤقت)
# في الإنتاج: نسخ احتياطي لقاعدة البيانات
*/30 * * * * /path/to/backup-script.sh
```

### 4. مراقبة النظام

- تفعيل سجلات الخادم (Server logs)
- مراقبة الأداء
- تنبيهات للأخطاء

## 🔍 الاختبار

### اختبارات ما قبل النشر:

1. **اختبار تسجيل الدخول**
   - تجربة جميع أدوار المستخدمين
   - التحقق من الصلاحيات

2. **اختبار الوظائف**
   - إضافة مخالفات
   - البحث والاستعلام
   - التقارير
   - إدارة المستخدمين

3. **اختبار الأمان**
   - محاولة الوصول غير المصرح
   - اختبار انتهاء الجلسات
   - التحقق من الصلاحيات

4. **اختبار الأداء**
   - سرعة تحميل الصفحات
   - استجابة النظام
   - التعامل مع بيانات كثيرة

5. **اختبار المتصفحات**
   - Chrome
   - Firefox
   - Safari
   - Edge

6. **اختبار الأجهزة**
   - Desktop
   - Tablet
   - Mobile

## 📱 التوافق

النظام يعمل على:
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

المتطلبات:
- ✅ JavaScript enabled
- ✅ localStorage support
- ✅ CSS3 support

## 🐛 استكشاف الأخطاء

### مشكلة: لا يتم تسجيل الدخول

**الحل:**
1. فتح Developer Console (F12)
2. التحقق من وجود أخطاء JavaScript
3. التحقق من تفعيل localStorage
4. مسح ذاكرة التخزين المؤقت

### مشكلة: الصفحة لا تظهر بشكل صحيح

**الحل:**
1. التأكد من تحميل جميع ملفات CSS
2. التحقق من CDN links
3. مسح ذاكرة المتصفح

### مشكلة: خطأ في الصلاحيات

**الحل:**
1. تسجيل الخروج وإعادة تسجيل الدخول
2. التحقق من دور المستخدم
3. مراجعة ملف auth.js

## 📞 الدعم الفني

للمشاكل التقنية:
- مراجعة ملف README.md
- فحص سجلات المتصفح (Console)
- التواصل مع فريق التطوير

## 🔐 أمان الإنتاج - Production Security Checklist

قبل النشر النهائي، تأكد من:

- [ ] تم تغيير جميع كلمات المرور الافتراضية
- [ ] تم تطبيق HTTPS
- [ ] تم تطبيق تشفير كلمات المرور
- [ ] تم استبدال localStorage بقاعدة بيانات
- [ ] تم تطبيق JWT tokens
- [ ] تم تطبيق Rate limiting
- [ ] تم تطبيق CSRF protection
- [ ] تم تطبيق Input validation
- [ ] تم إعداد النسخ الاحتياطي
- [ ] تم اختبار النظام بالكامل
- [ ] تم إعداد نظام المراقبة
- [ ] تم توثيق جميع التغييرات

## 📚 موارد إضافية

- [OWASP Security Guidelines](https://owasp.org/)
- [MDN Web Security](https://developer.mozilla.org/en-US/docs/Web/Security)
- [Let's Encrypt](https://letsencrypt.org/)

## 📄 الترخيص

جميع الحقوق محفوظة © 2025 - جامعة الإمام محمد بن سعود الإسلامية

---

**ملاحظة مهمة**: هذا النظام في حالته الحالية مناسب للتطوير والاختبار الداخلي فقط. للنشر في بيئة إنتاج حقيقية، يجب تطبيق جميع التوصيات الأمنية المذكورة أعلاه.
