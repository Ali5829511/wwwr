# معلومات قاعدة البيانات - Database Information

## 📊 نظام إدارة قاعدة البيانات

### نوع قاعدة البيانات
**localStorage** - قاعدة بيانات محلية في المتصفح

### الملفات المستخدمة
- `js/database.js` - ملف إدارة قاعدة البيانات الرئيسي

---

## ✅ البيانات الحقيقية الموجودة

### 1. جدول المستخدمين (Users Table)

**الموقع:** `localStorage.users`  
**عدد السجلات:** 3 مستخدمين افتراضيين

#### المستخدمون المسجلون:

| ID | اسم المستخدم | كلمة المرور | الاسم | البريد الإلكتروني | الصلاحية | الحالة |
|----|-------------|-------------|------|-------------------|----------|--------|
| 1 | admin | admin123 | مدير النظام | admin@university.edu.sa | admin | نشط |
| 2 | violations_officer | violations123 | مسؤول المخالفات | violations@university.edu.sa | violation_entry | نشط |
| 3 | inquiry_user | inquiry123 | موظف الاستعلام | inquiry@university.edu.sa | inquiry | نشط |

### 2. جدول المخالفات (Violations Table)

**الموقع:** `localStorage.violations`  
**عدد السجلات:** 0 (فارغ حالياً)

**الهيكل:**
```json
{
  "id": "معرف فريد",
  "plateNumber": "رقم اللوحة",
  "violationDate": "تاريخ المخالفة",
  "violationType": "نوع المخالفة",
  "location": "الموقع",
  "status": "الحالة",
  "createdDate": "تاريخ الإنشاء",
  "createdBy": "معرف المستخدم"
}
```

### 3. بيانات الملصقات (Stickers Data)

**الموقع:** مدمجة في `enhanced_stickers_management.html`  
**عدد السجلات:** 3 سجلات افتراضية

#### البيانات المتوفرة:

| رقم الهوية | اسم الساكن | الحالة | رقم اللوحة | نوع المركبة | نوع الوحدة | المبنى/الشقة |
|-----------|------------|--------|-----------|------------|-----------|-------------|
| 1234567890 | د. أحمد محمد علي | فعال | ر ق ل 1234 | سيدان | فلة | 15/25 |
| 9876543210 | د. فاطمة أحمد | فعال | ر ق ل 5678 | SUV | شقة | 8/45 |
| 5555555555 | د. محمد سعد | غير فعال | ر ق ل 9999 | هاتشباك | فلة | 12/10 |

---

## 🔧 وظائف قاعدة البيانات المتاحة

### إدارة المستخدمين
```javascript
// الحصول على جميع المستخدمين
await window.db.getUsers()

// الحصول على مستخدم بالمعرف
await window.db.getUserById(id)

// الحصول على مستخدم باسم المستخدم
await window.db.getUserByUsername(username)

// إضافة مستخدم جديد
await window.db.addUser(userData)

// تحديث مستخدم
await window.db.updateUser(id, userData)

// حذف مستخدم
await window.db.deleteUser(id)

// تحديث وقت آخر تسجيل دخول
await window.db.updateLastLogin(userId)
```

### إدارة المخالفات
```javascript
// الحصول على جميع المخالفات
await window.db.getViolations()

// إضافة مخالفة جديدة
await window.db.addViolation(violationData)

// تحديث مخالفة
await window.db.updateViolation(id, violationData)

// حذف مخالفة
await window.db.deleteViolation(id)

// البحث عن مخالفة برقم اللوحة
await window.db.searchViolationsByPlate(plateNumber)

// البحث عن مخالفات بتاريخ معين
await window.db.searchViolationsByDate(date)
```

### الإحصائيات
```javascript
// إحصائيات المستخدمين
await window.db.getUserStats()

// إحصائيات المخالفات
await window.db.getViolationStats()
```

### التصدير والاستيراد
```javascript
// تصدير البيانات
await window.db.exportData('all') // أو 'users' أو 'violations'

// استيراد البيانات
await window.db.importData(data)

// إعادة تعيين قاعدة البيانات
await window.db.resetDatabase()
```

---

## 📈 الإحصائيات الحالية

### إحصائيات المستخدمين
- **إجمالي المستخدمين:** 3
- **المستخدمون النشطون:** 3
- **المستخدمون غير النشطين:** 0
- **المدراء:** 1
- **موظفو المخالفات:** 1
- **موظفو الاستعلام:** 1

### إحصائيات المخالفات
- **إجمالي المخالفات:** 0
- **مخالفات هذا الشهر:** 0
- **مخالفات هذا الأسبوع:** 0

---

## ⚠️ تحذيرات أمنية مهمة

> **هذا النظام مصمم للتطوير والاختبار فقط!**

### المشاكل الأمنية الحالية:
1. ❌ كلمات المرور مخزنة بنص عادي (plain text)
2. ❌ البيانات مخزنة محلياً في المتصفح
3. ❌ لا يوجد تشفير للبيانات الحساسة
4. ❌ لا يوجد مصادقة من جانب الخادم
5. ❌ لا يوجد حماية CSRF

### متطلبات الإنتاج:
1. ✅ استخدام قاعدة بيانات حقيقية:
   - PostgreSQL
   - MySQL
   - MongoDB
   - SQL Server

2. ✅ تشفير كلمات المرور:
   - bcrypt
   - argon2
   - scrypt

3. ✅ إنشاء API خلفي آمن:
   - Node.js + Express
   - ASP.NET Core
   - Python + Flask/Django
   - PHP + Laravel

4. ✅ تطبيق بروتوكولات الأمان:
   - SSL/TLS (HTTPS)
   - JWT للمصادقة
   - Rate Limiting
   - CSRF Protection
   - Input Validation
   - SQL Injection Prevention

5. ✅ النسخ الاحتياطي:
   - نسخ احتياطي يومي
   - استعادة البيانات
   - تدقيق السجلات

---

## 🔄 كيفية استخدام قاعدة البيانات

### في المتصفح (Developer Console)
```javascript
// الوصول إلى قاعدة البيانات
const db = window.db;

// الحصول على جميع المستخدمين
const users = await db.getUsers();
console.log(users);

// إضافة مستخدم جديد
const result = await db.addUser({
  username: 'test_user',
  password: 'test123',
  name: 'مستخدم تجريبي',
  email: 'test@example.com',
  role: 'inquiry',
  status: 'active'
});
console.log(result);
```

### في الكود JavaScript
```javascript
// التأكد من تحميل قاعدة البيانات
if (window.db) {
  // استخدام قاعدة البيانات
  const users = await window.db.getUsers();
  console.log('Total users:', users.length);
}
```

---

## 📝 ملاحظات إضافية

1. **التخزين المحلي:** البيانات محفوظة في متصفح المستخدم فقط
2. **التطهير:** حذف بيانات المتصفح سيحذف جميع البيانات
3. **الأداء:** مناسب لعدد محدود من السجلات (<1000)
4. **القيود:** حد تخزين localStorage حوالي 5-10 MB
5. **التوافق:** يعمل على جميع المتصفحات الحديثة

---

## 📅 آخر تحديث
نوفمبر 2025

---

**للاستفسارات أو الدعم الفني، يرجى التواصل مع فريق التطوير**
