# نظام إرسال الإشعارات عبر البريد الإلكتروني
# Email Notification System

## 📧 نظرة عامة | Overview

تم إضافة نظام متكامل لإرسال الإشعارات عبر البريد الإلكتروني إلى نظام إدارة المرور. يستخدم النظام خدمة EmailJS لإرسال الإشعارات تلقائياً عند حدوث أحداث مهمة.

An integrated email notification system has been added to the Traffic Management System. The system uses EmailJS service to automatically send notifications when important events occur.

## ✨ الميزات | Features

### الإشعارات المدعومة | Supported Notifications
- ✅ إشعار عند إنشاء مستخدم جديد | New user creation notification
- ✅ إشعار عند تسجيل مخالفة جديدة | New violation registration notification
- ✅ إشعارات النظام العامة | General system notifications
- 🔜 إشعار إعادة تعيين كلمة المرور | Password reset notification (future)

### التحكم والإعدادات | Control & Settings
- ✅ تفعيل/تعطيل الخدمة | Enable/disable service
- ✅ تكوين بيانات EmailJS | Configure EmailJS credentials
- ✅ التحكم في أنواع الإشعارات | Control notification types
- ✅ اختبار إرسال البريد | Test email sending
- ✅ واجهة إدارة سهلة الاستخدام | User-friendly admin interface

## 🚀 كيفية الإعداد | Setup Instructions

### الخطوة 1: إنشاء حساب EmailJS
1. اذهب إلى [EmailJS](https://www.emailjs.com)
2. أنشئ حساباً مجانياً
3. قم بتسجيل الدخول

### الخطوة 2: إضافة خدمة البريد الإلكتروني
1. من لوحة التحكم، اذهب إلى **Email Services**
2. اضغط على **Add New Service**
3. اختر مزود البريد الإلكتروني (Gmail, Outlook, إلخ)
4. اتبع التعليمات لربط حسابك
5. احفظ **Service ID** (مثال: `service_abc123`)

### الخطوة 3: إنشاء قوالب البريد الإلكتروني
أنشئ القوالب التالية في EmailJS:

#### 1. قالب المستخدم الجديد (user_created)
**Template ID:** `template_user_created`

**المتغيرات المطلوبة:**
- `to_email`: البريد الإلكتروني للمستخدم
- `to_name`: اسم المستخدم
- `username`: اسم المستخدم للدخول
- `role`: دور المستخدم
- `login_url`: رابط صفحة تسجيل الدخول

**مثال على القالب:**
```
مرحباً {{to_name}}،

تم إنشاء حساب جديد لك في نظام إدارة المرور.

معلومات الحساب:
- اسم المستخدم: {{username}}
- الدور: {{role}}

يمكنك تسجيل الدخول من خلال الرابط التالي:
{{login_url}}

مع تحياتنا،
فريق نظام إدارة المرور
```

#### 2. قالب المخالفة الجديدة (violation_added)
**Template ID:** `template_violation_added`

**المتغيرات المطلوبة:**
- `to_email`: البريد الإلكتروني للإدارة
- `violation_id`: رقم المخالفة
- `plate_number`: رقم اللوحة
- `violation_type`: نوع المخالفة
- `violation_date`: تاريخ المخالفة
- `location`: موقع المخالفة
- `view_url`: رابط عرض المخالفة

**مثال على القالب:**
```
تنبيه: تم تسجيل مخالفة جديدة

تفاصيل المخالفة:
- رقم المخالفة: {{violation_id}}
- رقم اللوحة: {{plate_number}}
- نوع المخالفة: {{violation_type}}
- التاريخ: {{violation_date}}
- الموقع: {{location}}

لعرض التفاصيل الكاملة:
{{view_url}}
```

#### 3. قالب إعادة تعيين كلمة المرور (password_reset)
**Template ID:** `template_password_reset`

**المتغيرات المطلوبة:**
- `to_email`: البريد الإلكتروني للمستخدم
- `username`: اسم المستخدم
- `reset_link`: رابط إعادة التعيين
- `expiry_time`: مدة صلاحية الرابط

#### 4. قالب الإشعارات العامة (system_notification)
**Template ID:** `template_system_notification`

**المتغيرات المطلوبة:**
- `to_email`: البريد الإلكتروني
- `subject`: موضوع الرسالة
- `message`: محتوى الرسالة
- `system_name`: اسم النظام

### الخطوة 4: الحصول على المفتاح العام
1. من لوحة التحكم، اذهب إلى **Account**
2. انسخ **Public Key** (مثال: `user_xyz789`)

### الخطوة 5: تكوين النظام
1. سجل الدخول كمدير (admin)
2. اذهب إلى **لوحة التحكم الموحدة**
3. اضغط على **إعدادات البريد الإلكتروني**
4. أدخل المعلومات التالية:
   - معرف الخدمة (Service ID)
   - المفتاح العام (Public Key)
   - البريد الإلكتروني للإدارة
5. فعّل الخيارات المطلوبة
6. اضغط **حفظ الإعدادات**
7. اختبر الإعدادات بإرسال بريد تجريبي

## 📂 الملفات المضافة | Added Files

```
├── js/
│   └── email-service.js         # خدمة إرسال البريد الإلكتروني
├── email_settings.html          # صفحة إعدادات البريد الإلكتروني
└── EMAIL_NOTIFICATION_README.md # هذا الملف
```

## 🔧 الملفات المعدلة | Modified Files

- `unified_dashboard.html` - إضافة رابط إعدادات البريد الإلكتروني
- `advanced_users_management.html` - إضافة إشعار عند إنشاء مستخدم
- `المخالفات_المرورية.html` - إضافة إشعار عند تسجيل مخالفة

## 🎯 الاستخدام | Usage

### تفعيل الخدمة
1. اذهب إلى **إعدادات البريد الإلكتروني**
2. فعّل الخيار "تفعيل خدمة البريد الإلكتروني"
3. تأكد من إدخال جميع المعلومات المطلوبة
4. احفظ الإعدادات

### إيقاف الخدمة
1. اذهب إلى **إعدادات البريد الإلكتروني**
2. عطّل الخيار "تفعيل خدمة البريد الإلكتروني"
3. احفظ الإعدادات

### اختبار الإعدادات
1. اذهب إلى **إعدادات البريد الإلكتروني**
2. في قسم "اختبار الإعدادات"
3. أدخل بريدك الإلكتروني
4. اضغط "إرسال بريد تجريبي"
5. تحقق من صندوق الوارد

## 📊 API Reference

### EmailService Class

#### Methods

```javascript
// تهيئة الخدمة
emailService.init()

// تحميل الإعدادات
emailService.loadEmailSettings()

// حفظ الإعدادات
emailService.saveEmailSettings(settings)

// التحقق من تفعيل الخدمة
emailService.isEmailEnabled()

// إرسال بريد إلكتروني
await emailService.sendEmail(templateId, params)

// إرسال إشعار مستخدم جديد
await emailService.notifyUserCreated(userData)

// إرسال إشعار مخالفة جديدة
await emailService.notifyViolationAdded(violationData)

// إرسال إشعار إعادة تعيين كلمة المرور
await emailService.notifyPasswordReset(email, username, resetToken)

// إرسال إشعار عام
await emailService.notifySystem(recipient, subject, message)

// اختبار الإعدادات
await emailService.testEmailConfiguration(testEmail)

// الحصول على حالة الخدمة
emailService.getStatus()
```

## 🔒 الأمان | Security

### ملاحظات أمنية مهمة:
- ✅ **المفتاح العام (Public Key)** مصمم ليكون عاماً حسب نموذج أمان EmailJS - لا يحتوي على معلومات حساسة
- ⚠️ المفتاح العام يُخزن في `localStorage` - هذا طبيعي لتطبيقات EmailJS من جانب العميل
- ⚠️ EmailJS يدعم 200 بريد شهرياً في الخطة المجانية
- ✅ استخدم حساب بريد مخصص للتطبيق
- ✅ لا تستخدم بريدك الشخصي
- ⚠️ **مهم**: لا يتم تخزين كلمات مرور أو مفاتيح خاصة في النظام

### توصيات الإنتاج:
1. انقل معالجة البريد إلى الخادم (Server-side)
2. استخدم API خلفي آمن
3. قم بتشفير بيانات الاعتماد
4. أضف Rate Limiting
5. سجل جميع عمليات إرسال البريد

## 🐛 استكشاف الأخطاء | Troubleshooting

### المشكلة: لا يتم إرسال البريد
**الحلول:**
1. تأكد من تفعيل الخدمة في الإعدادات
2. تحقق من صحة Service ID و Public Key
3. تأكد من إنشاء القوالب المطلوبة في EmailJS
4. افتح Console في المتصفح للتحقق من الأخطاء
5. جرّب إرسال بريد تجريبي

### المشكلة: خطأ "EmailJS library not loaded"
**الحل:** تأكد من تحميل مكتبة EmailJS في الصفحة:
```html
<script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>
```

### المشكلة: البريد يصل إلى مجلد Spam
**الحلول:**
1. استخدم مزود بريد موثوق (Gmail, Outlook)
2. أضف السجلات المناسبة (SPF, DKIM) في إعدادات النطاق
3. تجنب الكلمات التي قد تُعتبر Spam
4. استخدم قوالب احترافية

## 📝 أمثلة | Examples

### مثال 1: إرسال إشعار مخصص
```javascript
await window.emailService.notifySystem(
    'user@example.com',
    'تنبيه مهم',
    'هذه رسالة اختبار من النظام'
);
```

### مثال 2: التحقق من حالة الخدمة
```javascript
const status = window.emailService.getStatus();
console.log('Email service enabled:', status.enabled);
console.log('Email service configured:', status.configured);
```

### مثال 3: إرسال إشعار عند حدث معين
```javascript
document.getElementById('myButton').addEventListener('click', async () => {
    if (window.emailService.isEmailEnabled()) {
        await window.emailService.notifySystem(
            'admin@university.edu.sa',
            'تم الضغط على الزر',
            'قام مستخدم بالضغط على الزر في النظام'
        );
    }
});
```

## 🔮 التطوير المستقبلي | Future Development

- [ ] إضافة ميزة إعادة تعيين كلمة المرور
- [ ] إضافة قوالب بريد إلكتروني متقدمة مع HTML
- [ ] دعم المرفقات
- [ ] إضافة سجل لعمليات إرسال البريد
- [ ] إضافة إشعارات دورية (مثل التقارير الأسبوعية)
- [ ] دعم لغات متعددة في القوالب
- [ ] تكامل مع خدمات بريد أخرى (SendGrid, AWS SES)

## 📞 الدعم | Support

للمساعدة والدعم:
- راجع التوثيق أعلاه
- افتح Issue في GitHub
- راجع [توثيق EmailJS](https://www.emailjs.com/docs/)

## 📄 الترخيص | License

جميع الحقوق محفوظة © 2025 - جامعة الإمام محمد بن سعود الإسلامية

---

**ملاحظة:** هذا النظام مصمم للاستخدام التعليمي والتطوير. في بيئة الإنتاج، يُنصح باستخدام حل خادم (server-side) آمن لإرسال البريد الإلكتروني.

**Note:** This system is designed for educational and development use. In production environment, it is recommended to use a secure server-side solution for sending emails.
